# Khatma Site - Full Package

This package contains a full-stack Node.js + SQLite web app for managing a monthly Quran completion.

Files:
- server.js           : Express backend
- package.json
- public/             : Frontend site (index.html, tarteel.mp3, design.pdf)
- .env.example        : Environment variables example
- deploy.sh           : DigitalOcean/Ubuntu deploy helper
- Procfile            : Heroku
- Dockerfile          : Docker image
- full_khatma_with_backend.zip : packaged zip (this file)

## Quick start (local)
1. Copy `.env.example` to `.env` and fill values.
2. Run:
   ```
   npm install
   npm start
   ```
3. Open http://localhost:3000

## Deploy
See `deploy.sh` for a simple DigitalOcean/Ubuntu setup, or use Heroku with the `Procfile`.

## SMTP
Configure SMTP vars in `.env` to enable real email sending.

Admin credentials default to the values in `.env` (ADMIN_EMAIL, ADMIN_PASS).
