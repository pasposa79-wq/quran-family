#!/bin/bash
set -e
PROJECT_DIR=/var/www/khatma
echo "Ensure project files are in $PROJECT_DIR and .env is configured"
sudo apt update
sudo apt install -y nodejs npm nginx
cd $PROJECT_DIR
npm install
# create systemd service
cat <<'EOF' | sudo tee /etc/systemd/system/khatma.service
[Unit]
Description=Khatma Node App
After=network.target

[Service]
ExecStart=/usr/bin/node /var/www/khatma/server.js
Restart=always
User=nobody
EnvironmentFile=/var/www/khatma/.env

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable khatma
sudo systemctl start khatma
# Nginx config
cat <<'EOF' | sudo tee /etc/nginx/sites-available/khatma
server {
    listen 80;
    server_name _;
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF
sudo ln -sf /etc/nginx/sites-available/khatma /etc/nginx/sites-enabled/
sudo systemctl restart nginx
echo "Deployed"
