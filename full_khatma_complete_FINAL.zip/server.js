/*
 Simple Express server for ختمة site
 - Uses SQLite (file: khatma.db)
 - Provides API endpoints for login, participants, notes, khatmas, and send-email (via SMTP)
 Configure via environment variables (see .env.example)
*/
const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const session = require('express-session');
const path = require('path');
const nodemailer = require('nodemailer');

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'pasposa79@gmail.com';
const ADMIN_PASS = process.env.ADMIN_PASS || '12345';
const SESSION_SECRET = process.env.SESSION_SECRET || 'khatma_secret_change_me';

const dbFile = path.join(__dirname, 'khatma.db');
const db = new sqlite3.Database(dbFile);

const app = express();
app.use(bodyParser.json());
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}));

// Serve frontend static files
app.use('/', express.static(path.join(__dirname, 'public')));

// Initialize DB
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS participants (id INTEGER PRIMARY KEY, name TEXT, part1 INTEGER, part2 INTEGER)`);
  db.run(`CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, content TEXT, updated_at TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS khatmas (id INTEGER PRIMARY KEY, title TEXT, date TEXT, meta TEXT)`);
  db.get("SELECT COUNT(*) as cnt FROM participants", (err, row)=>{
    if(!err && row && row.cnt < 15){
      const stmt = db.prepare("INSERT INTO participants (name, part1, part2) VALUES (?,?,?)");
      for(let i=1;i<=15;i++){
        stmt.run(`المشارك ${i}`, null, null);
      }
      stmt.finalize();
    }
  });
  db.get("SELECT COUNT(*) as cnt FROM notes", (e,r)=>{
    if(!e && r && r.cnt===0){
      db.run("INSERT INTO notes (content, updated_at) VALUES (?,?)", ["", new Date().toISOString()]);
    }
  });
});

// Authentication
app.post('/api/login', (req,res)=>{
  const {email, password} = req.body;
  if(email === ADMIN_EMAIL && password === ADMIN_PASS){
    req.session.admin = {email};
    return res.json({ok:true});
  }
  res.status(401).json({ok:false, message:'invalid'});
});
app.post('/api/logout', (req,res)=>{
  req.session.destroy(()=>res.json({ok:true}));
});
function requireAdmin(req,res,next){
  if(req.session && req.session.admin) return next();
  return res.status(401).json({ok:false});
}

// Participants API
app.get('/api/participants', requireAdmin, (req,res)=>{
  db.all("SELECT id,name,part1,part2 FROM participants ORDER BY id", (err, rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});
app.post('/api/participants/:id', requireAdmin, (req,res)=>{
  const id = parseInt(req.params.id,10);
  const {part1, part2, name} = req.body;
  db.run("UPDATE participants SET part1=?, part2=?, name=? WHERE id=?",
    [part1 || null, part2 || null, name || `المشارك ${id}`, id],
    function(err){
      if(err) return res.status(500).json({error:err.message});
      res.json({ok:true});
    });
});

// Notes API
app.get('/api/notes', requireAdmin, (req,res)=>{
  db.get("SELECT content, updated_at FROM notes ORDER BY id DESC LIMIT 1", (err,row)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(row || {content:'', updated_at:null});
  });
});
app.post('/api/notes', requireAdmin, (req,res)=>{
  const {content} = req.body;
  db.run("UPDATE notes SET content=?, updated_at=? WHERE id=(SELECT id FROM notes ORDER BY id LIMIT 1)",
    [content || '', new Date().toISOString()], function(err){
      if(err) return res.status(500).json({error:err.message});
      res.json({ok:true});
    });
});

// Khatmas API
app.get('/api/khatmas', requireAdmin, (req,res)=>{
  db.all("SELECT id,title,date,meta FROM khatmas ORDER BY id DESC", (err, rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});
app.post('/api/khatmas', requireAdmin, (req,res)=>{
  const {title, date, meta} = req.body;
  db.run("INSERT INTO khatmas (title,date,meta) VALUES (?,?,?)", [title,date,meta||''], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({ok:true, id:this.lastID});
  });
});

// Send Email
app.post('/api/send-email', requireAdmin, async (req,res)=>{
  const {subject, body, to} = req.body;
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if(!host || !user || !pass){
    return res.status(400).json({ok:false, message:'SMTP not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS.'});
  }
  try{
    const transporter = nodemailer.createTransport({ host, port: parseInt(port,10)||587, secure:false, auth:{user, pass} });
    const info = await transporter.sendMail({
      from: `"ختمتنا" <${user}>`,
      to: to || user,
      subject,
      html: `<pre>${JSON.stringify(body,null,2)}</pre>`
    });
    res.json({ok:true, info});
  } catch(err){
    res.status(500).json({ok:false, error:err.message});
  }
});

// Fallback to frontend
app.use((req,res)=> res.sendFile(path.join(__dirname,'public','index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));
